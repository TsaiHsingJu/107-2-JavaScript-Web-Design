let n1 = parseInt(prompt("Enter an interger N1"));
let n2 = parseInt(prompt("Enter an interger N2"));

console.log("%d + %d = %d\n", n1, n2, n1+n2);
console.log("%d - %d = %d\n", n1, n2, n1-n2);
console.log("%d * %d = %d\n", n1, n2, n1*n2);
console.log("%d / %d = %d\n", n1, n2, n1/n2);

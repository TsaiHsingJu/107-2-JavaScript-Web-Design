let n1 = prompt('請輸入第一個數字')
let n2 = prompt('請輸入第二個數字')


console.log(`
            ${n1} + ${n2} = ${+n1 + +n2}
            ${n1} - ${n2} = ${+n1 - +n2}
            ${n1} * ${n2} = ${+n1 * +n2}
            ${n1} / ${n2} = ${(+n1 / +n2).toFixed(3)}
            `)


